*PADS-LIBRARY-PART-TYPES-V9*

ASWD-S2-0005-T ASWDS20005T I ANA 7 1 0 0 0
TIMESTAMP 2026.06.30.21.39.17
"Mouser Part Number" 
"Mouser Price/Stock" 
"Manufacturer_Name" ABRACON
"Manufacturer_Part_Number" ASWD-S2-0005-T
"Description" RF Switch IC Bluetooth, GNSS, GSM, LTE, WCDMA, WiFi SPDT SOT-363-6L
"Datasheet Link" https://abracon.com/datasheets/ASWD-S2-0005.pdf
"Geometry.Height" 1.05mm
GATE 1 6 0
ASWD-S2-0005-T
1 0 U RF2
2 0 U GND
3 0 U RF1
4 0 U VDD
5 0 U RFC
6 0 U VCTL

*END*
*REMARK* SamacSys ECAD Model
21168011/1599319/2.50/6/3/Integrated Circuit
