*PADS-LIBRARY-PART-TYPES-V9*

BGS12WN6E6329XTSA1 BGS12WN6E6329XTSA1 I ANA 7 1 0 0 0
TIMESTAMP 2026.06.26.22.03.15
"Mouser Part Number" 726-BGS12WN6E6329XTS
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Infineon-Technologies/BGS12WN6E6329XTSA1?qs=mELouGlnn3dQkhOAI%252B1UhQ%3D%3D
"Manufacturer_Name" Infineon
"Manufacturer_Part_Number" BGS12WN6E6329XTSA1
"Description" RF Switch ICs Y
"Datasheet Link" https://www.mouser.ca/datasheet/2/196/Infineon_BGS12WN6_DataSheet_v02_05_EN-3360659.pdf
"Geometry.Height" 0.4mm
GATE 1 6 0
BGS12WN6E6329XTSA1
1 0 U RF2
2 0 U GND
3 0 U RF1
4 0 U VDD
5 0 U RFIN
6 0 U CTRL

*END*
*REMARK* SamacSys ECAD Model
19749338/1599319/2.50/6/4/Integrated Circuit
