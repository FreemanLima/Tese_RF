*PADS-LIBRARY-PART-TYPES-V9*

CC1101RGPR QFN50P400X400X100-21N-D I ANA 7 1 0 0 0
TIMESTAMP 2026.06.30.18.58.25
"Mouser Part Number" 595-CC1101RGPR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/CC1101RGPR?qs=OHhYoCux73lreNWI41kZ9Q%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" CC1101RGPR
"Description" Low-Power Sub-1GHz RF Transceiver
"Datasheet Link" http://www.ti.com/lit/gpn/cc1101
"Geometry.Height" 1mm
GATE 1 21 0
CC1101RGPR
1 0 U SCLK
2 0 U SO_(GDO1)
3 0 U GDO2
4 0 U DVDD
5 0 U DCOUPL
6 0 U GDO0_(ATEST)
7 0 U CSN
8 0 U XOSC_Q1
9 0 U AVDD_1
10 0 U XOSC_Q2
15 0 U AVDD_4
14 0 U AVDD_3
13 0 U RF_N
12 0 U RF_P
11 0 U AVDD_2
21 0 U GND_3
20 0 U SI
19 0 U GND_2
18 0 U DGUARD
17 0 U RBIAS
16 0 U GND_1

*END*
*REMARK* SamacSys ECAD Model
243912/1599319/2.50/21/3/Integrated Circuit
