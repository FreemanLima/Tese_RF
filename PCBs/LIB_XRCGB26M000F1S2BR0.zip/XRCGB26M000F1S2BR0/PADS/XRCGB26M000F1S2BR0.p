*PADS-LIBRARY-PART-TYPES-V9*

XRCGB26M000F1S2BR0 XRCGB I OSC 7 1 0 0 0
TIMESTAMP 2026.06.30.21.00.49
"Mouser Part Number" 
"Mouser Price/Stock" 
"Manufacturer_Name" Murata Electronics
"Manufacturer_Part_Number" XRCGB26M000F1S2BR0
"Description" Specification of Crystal Unit Frequency: 26.0000MHz / Size: 2.0 x 1.6mm  
"Datasheet Link" https://www.murata.com/products/productdata/8811171282974/SPEC-XRCGB26M000F1S2BR0.pdf
"Geometry.Height" 0.7mm
GATE 1 4 0
XRCGB26M000F1S2BR0
1 0 U XTAL_1
2 0 U NC_1
3 0 U XTAL_2
4 0 U NC_2

*END*
*REMARK* SamacSys ECAD Model
19146559/1599319/2.50/4/2/Crystal or Oscillator
